Java OOP GUI project - Simple standalone faculty-student database management app using textfiles as database storage.
